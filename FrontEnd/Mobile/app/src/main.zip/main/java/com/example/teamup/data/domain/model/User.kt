package com.example.teamup.data.domain.model

data class User(
    val name: String,
    val email: String
)