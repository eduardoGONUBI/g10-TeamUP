// File: app/src/main/java/com/example/teamup/presentation/profile/PublicProfileViewModel.kt
package com.example.teamup.presentation.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.teamup.data.remote.*
import com.example.teamup.data.remote.api.AchievementsApi
import com.example.teamup.data.remote.api.AuthApi
import com.example.teamup.data.remote.model.AchievementDto
import com.example.teamup.data.remote.model.AchievementsResponse
import com.example.teamup.data.remote.model.ProfileResponse
import com.example.teamup.data.remote.model.PublicUserDto
import com.example.teamup.data.remote.model.ReputationResponse
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel for loading *another* user's public profile (read-only).
 *
 * 1) GET /api/users/{id}        → name, avatar_url, location, sports
 * 2) GET /api/profile/{id}      → xp + level
 * 3) GET /api/rating/{id}       → rep counts + score
 * 4) GET /api/achievements/{id} → unlocked achievements
 */
class PublicProfileViewModel(
    private val userId: Int,
    private val bearer: String    // must be "Bearer <token>"
) : ViewModel() {

    private val authApi = AuthApi.create()
    private val achApi  = AchievementsApi.create()

    // ─── PUBLIC STATE ────────────────────────────────────────
    private val _name       = MutableStateFlow("Loading…")
    val name: StateFlow<String>          = _name

    private val _avatarUrl  = MutableStateFlow<String?>(null)
    val avatarUrl: StateFlow<String?>    = _avatarUrl

    private val _location   = MutableStateFlow<String?>(null)
    val location: StateFlow<String?>     = _location

    private val _sports     = MutableStateFlow<List<String>>(emptyList())
    val sports: StateFlow<List<String>>  = _sports

    private val _level      = MutableStateFlow(0)
    val level: StateFlow<Int>            = _level

    private val _behaviour  = MutableStateFlow<Int?>(null)
    val behaviour: StateFlow<Int?>       = _behaviour

    private val _repLabel   = MutableStateFlow("—")
    val repLabel: StateFlow<String>      = _repLabel

    private val _achievements = MutableStateFlow<List<AchievementDto>>(emptyList())
    val achievements: StateFlow<List<AchievementDto>> = _achievements

    private val _error      = MutableStateFlow<String?>(null)
    val error: StateFlow<String?>        = _error

    init {
        loadPublicProfile()
    }

    private fun loadPublicProfile() = viewModelScope.launch {
        try {
            // ─── 1) Fetch /api/users/{id} → name, avatar_url, location, sports
            val publicUser: PublicUserDto = authApi.getUser(userId, bearer)
            _name.value      = publicUser.name
            _avatarUrl.value = publicUser.avatar_url
            _location.value  = publicUser.location

            // Convert the list of SportDto to a list of their names, if any
            _sports.value = publicUser.sports?.map { it.name } ?: emptyList()

            // ─── 2) Fetch /api/profile/{id} → xp + level
            val profile: ProfileResponse = achApi.getProfile(userId, bearer)
            _level.value = profile.level

            // ─── 3) Fetch /api/rating/{id} → score + count details
            val rep: ReputationResponse = achApi.getReputation(userId, bearer)
            _behaviour.value = rep.score

            // Compute the “top feedback” label:
            val counts: List<Pair<String, Int>> = listOf(
                "Good teammate"   to (rep.good_teammate_count ?: 0),
                "Friendly player" to (rep.friendly_count ?: 0),
                "Team player"     to (rep.team_player_count ?: 0),
                "Watchlisted"     to (rep.toxic_count ?: 0),
                "Bad sport"       to (rep.bad_sport_count ?: 0),
                "Frequent AFK"    to (rep.afk_count ?: 0)
            )
            val top: Pair<String, Int>? = counts.maxByOrNull { it.second }
            _repLabel.value = if (top != null && top.second > 0) {
                "${top.first} (${top.second})"
            } else {
                "—"
            }

            // ─── 4) Fetch /api/achievements/{id} → unlocked achievements
            val achList: AchievementsResponse = achApi.listAchievements(userId, bearer)
            _achievements.value = achList.achievements

        } catch (e: Exception) {
            _error.value = e.message
        }
    }
}
